/**
 * components/ReadingModal.js
 *
 * Modal de leitura integrado com gamificação
 * Permite ao usuário marcar progresso de leitura e ganhar XP
 */

import { startReading, updateReadingProgress } from '../services/ReadingService.js';
import { supabase } from '../services/supabase.js';

/**
 * Gera o HTML do modal de leitura
 * @param {Object} book - Dados do livro
 * @param {Object} progress - Progresso atual (opcional)
 * @returns {string}
 */
export function ReadingModal(book, progress = null) {
  const currentPage = progress?.current_page || 0;
  const totalPages = progress?.total_pages || book.totalPages || 100; // fallback
  const completion = Math.round((currentPage / totalPages) * 100);

  return `
    <div class="reading-modal-overlay" id="reading-modal">
      <div class="reading-modal">
        <div class="reading-header">
          <div class="reading-book-info">
            <h2 class="reading-title">${book.title}</h2>
            <p class="reading-author">por ${book.author}</p>
          </div>
          <button class="reading-close" data-action="close-reading" aria-label="Fechar leitura">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        </div>

        <div class="reading-content">
          <div class="reading-progress-section">
            <div class="progress-display">
              <div class="progress-text">
                <span class="current-page">${currentPage}</span>
                <span class="progress-separator">/</span>
                <span class="total-pages">${totalPages}</span>
                <span class="completion-percentage">(${completion}%)</span>
              </div>
              <div class="progress-bar-container">
                <div class="progress-bar" style="width: ${completion}%"></div>
              </div>
            </div>

            <div class="page-controls">
              <button class="page-btn" data-action="prev-page" ${currentPage <= 0 ? 'disabled' : ''}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <polyline points="15,18 9,12 15,6"></polyline>
                </svg>
                Anterior
              </button>

              <div class="page-input-group">
                <label for="page-input">Página atual:</label>
                <input
                  type="number"
                  id="page-input"
                  class="page-input"
                  value="${currentPage}"
                  min="0"
                  max="${totalPages}"
                  data-action="update-page"
                />
              </div>

              <button class="page-btn" data-action="next-page" ${currentPage >= totalPages ? 'disabled' : ''}>
                Próxima
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <polyline points="9,18 15,12 9,6"></polyline>
                </svg>
              </button>
            </div>
          </div>

          <div class="reading-iframe-container">
            <iframe
              src="${book.url}"
              class="reading-iframe"
              title="Leitura: ${book.title}"
              allowfullscreen
            ></iframe>
          </div>
        </div>

        <div class="reading-footer">
          <div class="reading-stats">
            <div class="stat-item">
              <span class="stat-label">XP ganho:</span>
              <span class="stat-value">${currentPage * 10} XP</span>
            </div>
            <div class="stat-item">
              <span class="stat-label">Tempo estimado:</span>
              <span class="stat-value">${Math.round(totalPages / 2)} min</span>
            </div>
          </div>

          <div class="reading-actions">
            <button class="btn-secondary" data-action="close-reading">
              Fechar
            </button>
            <button class="btn-primary" data-action="finish-reading" ${currentPage < totalPages ? 'disabled' : ''}>
              Finalizar Livro
            </button>
          </div>
        </div>
      </div>
    </div>`;
}

/**
 * Mostra o modal de leitura para um livro
 * @param {Object} book - Dados do livro
 */
export async function showReadingModal(book) {
  try {
    // Obter usuário atual
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      alert('Você precisa estar logado para ler livros.');
      return;
    }

    // Verificar se já existe progresso para este livro
    const { data: progress } = await supabase
      .from('reading_progress')
      .select('*')
      .eq('book_id', book.id)
      .eq('user_id', user.id)
      .single();

    // Se não existe progresso, iniciar leitura
    if (!progress) {
      await startReading(user.id, book.id, book.totalPages || 100);
    }

    // Renderizar modal
    const modalHtml = ReadingModal(book, progress);
    document.body.insertAdjacentHTML('beforeend', modalHtml);

    // Adicionar event listeners
    setupReadingModalEvents(book);

  } catch (error) {
    console.error('Erro ao abrir modal de leitura:', error);
    // Fallback: abrir em nova aba
    window.open(book.url, '_blank', 'noopener');
  }
}

/**
 * Configura os event listeners do modal de leitura
 * @param {Object} book - Dados do livro
 */
function setupReadingModalEvents(book) {
  const modal = document.getElementById('reading-modal');

  modal.addEventListener('click', async (e) => {
    const action = e.target.closest('[data-action]')?.dataset.action;

    switch (action) {
      case 'close-reading':
        modal.remove();
        break;

      case 'prev-page':
        await updatePage(book, -1);
        break;

      case 'next-page':
        await updatePage(book, 1);
        break;

      case 'update-page':
        if (e.type === 'input' || e.type === 'change') {
          const newPage = parseInt(e.target.value) || 0;
          await updatePageAbsolute(book, newPage);
        }
        break;

      case 'finish-reading':
        await finishReading(book);
        modal.remove();
        break;
    }
  });

  // Event listener para input de página
  const pageInput = modal.querySelector('#page-input');
  pageInput.addEventListener('change', (e) => {
    const event = new CustomEvent('click', { bubbles: true });
    e.target.setAttribute('data-action', 'update-page');
    e.target.dispatchEvent(event);
  });

  // Fechar modal ao clicar no overlay
  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      modal.remove();
    }
  });

  // Previne fechamento ao clicar no modal interno
  modal.querySelector('.reading-modal').addEventListener('click', (e) => {
    e.stopPropagation();
  });
}

/**
 * Atualiza a página atual (relativo)
 * @param {Object} book - Dados do livro
 * @param {number} delta - Mudança na página (+1 ou -1)
 */
async function updatePage(book, delta) {
  const pageInput = document.querySelector('#page-input');
  const currentPage = parseInt(pageInput.value) || 0;
  const newPage = Math.max(0, currentPage + delta);

  await updatePageAbsolute(book, newPage);
}

/**
 * Atualiza para uma página específica
 * @param {Object} book - Dados do livro
 * @param {number} newPage - Nova página
 */
async function updatePageAbsolute(book, newPage) {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const totalPages = parseInt(document.querySelector('.total-pages').textContent) || 100;
    const clampedPage = Math.max(0, Math.min(totalPages, newPage));

    // Atualizar progresso no banco
    await updateReadingProgress(user.id, book.id, clampedPage);

    // Atualizar UI
    updateReadingUI(clampedPage, totalPages);

  } catch (error) {
    console.error('Erro ao atualizar página:', error);
  }
}

/**
 * Finaliza a leitura do livro
 * @param {Object} book - Dados do livro
 */
async function finishReading(book) {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const totalPages = parseInt(document.querySelector('.total-pages').textContent) || 100;
    await updateReadingProgress(user.id, book.id, totalPages, 'finished');

    // Mostrar notificação de sucesso
    showNotification('🎉 Livro finalizado! XP ganho: ' + (totalPages * 10));

  } catch (error) {
    console.error('Erro ao finalizar leitura:', error);
  }
}

/**
 * Atualiza a interface do modal de leitura
 * @param {number} currentPage - Página atual
 * @param {number} totalPages - Total de páginas
 */
function updateReadingUI(currentPage, totalPages) {
  const completion = Math.round((currentPage / totalPages) * 100);

  // Atualizar texto
  document.querySelector('.current-page').textContent = currentPage;
  document.querySelector('.completion-percentage').textContent = `(${completion}%)`;

  // Atualizar barra de progresso
  document.querySelector('.progress-bar').style.width = `${completion}%`;

  // Atualizar input
  document.querySelector('#page-input').value = currentPage;

  // Atualizar botões
  const prevBtn = document.querySelector('[data-action="prev-page"]');
  const nextBtn = document.querySelector('[data-action="next-page"]');
  const finishBtn = document.querySelector('[data-action="finish-reading"]');

  prevBtn.disabled = currentPage <= 0;
  nextBtn.disabled = currentPage >= totalPages;
  finishBtn.disabled = currentPage < totalPages;

  // Atualizar XP
  document.querySelector('.stat-value').textContent = `${currentPage * 10} XP`;
}

/**
 * Mostra uma notificação temporária
 * @param {string} message - Mensagem da notificação
 */
function showNotification(message) {
  const notification = document.createElement('div');
  notification.className = 'notification success';
  notification.textContent = message;

  document.body.appendChild(notification);

  setTimeout(() => {
    notification.remove();
  }, 3000);
}
</content>
<parameter name="filePath">/home/samuel/Área de trabalho/extensao/leituracao_supabase/components/ReadingModal.js</parameter>
